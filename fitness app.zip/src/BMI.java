import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class BMI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textFieldWeight;
    private JTextField textFieldHeight;
    private JTextField textFieldAge;
    private JTextField textFieldBMI;
    private JTextField textFieldStatus;
    private double weight = 0.0d, height = 0.0d, bmi = 0.0d;
    private int age;
    private String username;
    private Dashboard dashboard; // Reference to the Dashboard
    private String gender; // Variable to store gender

    // Main method to run the application
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                BMI frame = new BMI("defaultUsername", null); // No dashboard in this example
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    // Constructor with username and Dashboard reference
    public BMI(String username, Dashboard dashboard) {
        this.username = username;
        this.dashboard = dashboard; // Store the dashboard reference
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 461, 492);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(240, 240, 240)); // Light gray background
        contentPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblTitle = new JLabel("Know Your BMI");
        lblTitle.setBounds(120, 25, 280, 41);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 28));
        lblTitle.setForeground(new Color(0, 102, 204)); // Blue color
        contentPane.add(lblTitle);

        JLabel lblWeight = new JLabel("Your Weight (Kg):");
        lblWeight.setFont(new Font("Arial", Font.BOLD, 18));
        lblWeight.setBounds(25, 120, 162, 41);
        contentPane.add(lblWeight);

        JLabel lblHeight = new JLabel("Your Height (cm):");
        lblHeight.setFont(new Font("Arial", Font.BOLD, 18));
        lblHeight.setBounds(25, 171, 162, 24);
        contentPane.add(lblHeight);

        JLabel lblAge = new JLabel("Your Age:");
        lblAge.setFont(new Font("Arial", Font.BOLD, 18));
        lblAge.setBounds(50, 220, 97, 24);
        contentPane.add(lblAge);

        // Gender selection
        JLabel lblGender = new JLabel("Your Gender:");
        lblGender.setFont(new Font("Arial", Font.BOLD, 18));
        lblGender.setBounds(25, 86, 120, 24);
        contentPane.add(lblGender);

        JRadioButton rdbtnMale = new JRadioButton("Male");
        rdbtnMale.setFont(new Font("Tahoma", Font.PLAIN, 15));
        rdbtnMale.setBounds(197, 88, 75, 24);
        contentPane.add(rdbtnMale);

        JRadioButton rdbtnFemale = new JRadioButton("Female");
        rdbtnFemale.setFont(new Font("Tahoma", Font.PLAIN, 15));
        rdbtnFemale.setBounds(302, 88, 80, 24);
        contentPane.add(rdbtnFemale);

        // Grouping the radio buttons
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(rdbtnMale);
        genderGroup.add(rdbtnFemale);

        textFieldWeight = new JTextField();
        textFieldWeight.setFont(new Font("Arial", Font.PLAIN, 16));
        textFieldWeight.setBounds(192, 128, 190, 24);
        contentPane.add(textFieldWeight);
        textFieldWeight.setColumns(10);

        textFieldHeight = new JTextField();
        textFieldHeight.setFont(new Font("Arial", Font.PLAIN, 16));
        textFieldHeight.setBounds(192, 171, 190, 24);
        contentPane.add(textFieldHeight);
        textFieldHeight.setColumns(10);

        textFieldAge = new JTextField();
        textFieldAge.setFont(new Font("Arial", Font.PLAIN, 16));
        textFieldAge.setBounds(192, 220, 190, 24);
        contentPane.add(textFieldAge);
        textFieldAge.setColumns(10);

        JButton btnCheck = new JButton("Check");
        btnCheck.setBackground(new Color(0, 204, 102)); // Green color
        btnCheck.setFont(new Font("Arial", Font.BOLD, 20));
        btnCheck.setBounds(120, 254, 97, 51);
        btnCheck.setForeground(Color.WHITE); // White text
        btnCheck.setBorder(BorderFactory.createEmptyBorder());
        contentPane.add(btnCheck);

        JButton btnClear = new JButton("Clear");
        btnClear.setBackground(new Color(204, 0, 0)); // Red color
        btnClear.setFont(new Font("Arial", Font.BOLD, 20));
        btnClear.setBounds(228, 254, 97, 51);
        btnClear.setForeground(Color.WHITE); // White text
        btnClear.setBorder(BorderFactory.createEmptyBorder());
        contentPane.add(btnClear);

        JLabel lblBMI = new JLabel("Your BMI:");
        lblBMI.setFont(new Font("Arial", Font.BOLD, 18));
        lblBMI.setBounds(25, 315, 113, 31);
        contentPane.add(lblBMI);

        textFieldBMI = new JTextField();
        textFieldBMI.setBackground(SystemColor.window);
        textFieldBMI.setFont(new Font("Arial", Font.BOLD, 16));
        textFieldBMI.setBounds(120, 315, 190, 31);
        textFieldBMI.setEditable(false);
        contentPane.add(textFieldBMI);

        JLabel lblStatus = new JLabel("Status:");
        lblStatus.setFont(new Font("Arial", Font.BOLD, 18));
        lblStatus.setBounds(25, 356, 90, 30);
        contentPane.add(lblStatus);

        textFieldStatus = new JTextField();
        textFieldStatus.setBackground(SystemColor.window);
        textFieldStatus.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 16));
        textFieldStatus.setBounds(121, 356, 294, 30);
        textFieldStatus.setEditable(false);
        contentPane.add(textFieldStatus);

        // Event for the "Check" button
        btnCheck.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (textFieldWeight.getText().trim().isEmpty() ||
                        textFieldHeight.getText().trim().isEmpty() ||
                        textFieldAge.getText().trim().isEmpty() ||
                        (!rdbtnMale.isSelected() && !rdbtnFemale.isSelected())) {

                        textFieldStatus.setText("All fields are required.");
                        return;
                    }

                    age = Integer.parseInt(textFieldAge.getText());
                    weight = Double.parseDouble(textFieldWeight.getText());
                    height = Double.parseDouble(textFieldHeight.getText());

                    height = height / 100; // Convert height to meters
                    if (height <= 0 || weight <= 0 || age <= 0) {
                        textFieldStatus.setText("Invalid input");
                        return;
                    }

                    // Determine gender
                    gender = rdbtnMale.isSelected() ? "Male" : "Female";

                    bmi = weight / (height * height);
                    textFieldBMI.setText(String.format("%.2f", bmi));

                    String status = getBMICategory(age, bmi, gender);
                    textFieldStatus.setText(status);

                    // Pass BMI and status to Dashboard (if it's provided)
                   
                    

                } catch (NumberFormatException ex) {
                    textFieldStatus.setText("Invalid input");
                }
            }
        });

        // Clear button functionality
        btnClear.addActionListener(e -> {
            textFieldWeight.setText("");
            textFieldHeight.setText("");
            textFieldAge.setText("");
            textFieldBMI.setText("");
            textFieldStatus.setText("");
            genderGroup.clearSelection(); // Clear gender selection
        });

        // Back button to return to Dashboard
        JButton btnBack = new JButton("Back");
        btnBack.setFont(new Font("Arial", Font.BOLD, 18));
        btnBack.setBackground(new Color(0, 102, 204)); // Blue color
        btnBack.setBounds(171, 405, 100, 40);
        btnBack.setForeground(Color.WHITE); // White text
        btnBack.setBorder(BorderFactory.createEmptyBorder());
        contentPane.add(btnBack);

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (dashboard != null) {
                    dashboard.setVisible(true);  // Show the Dashboard
                }
                dispose(); // Close the BMI window
            }
        });
    }

    // Method to categorize BMI based on age and gender
    private String getBMICategory(int age, double bmi, String gender) {
        if (age < 18) {
            if (bmi < 15.0) return "Oops!! You are Underweight.";
            if (bmi < 20.0) return "Yippie!! You have a normal weight.";
            if (bmi < 25.0) return "Oops!! You are Overweight.";
            return "Oops!! You are obese.";
        } else {
            if (gender.equals("Male")) {
                if (bmi < 18.5) return "Oops!! You are Underweight.";
                if (bmi < 24.9) return "Yippie!! You have a normal weight.";
                if (bmi < 29.9) return "Oops!! You are Overweight.";
                return "Oops!! You are obese.";
            } else { // Female
                if (bmi < 18.5) return "Oops!! You are Underweight.";
                if (bmi < 24.9) return "Yippie!! You have a normal weight.";
                if (bmi < 29.9) return "Oops!! You are Overweight.";
                return "Oops!! You are obese.";
            }
        }
    }
}