import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Conn {

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/fitness"; // Update with your database URL
    private static final String DB_USERNAME = "Vrushali"; // Update with your database username
    private static final String DB_PASSWORD = "Vrushali@1220"; // Update with your database password

    // Method to establish a connection to the database
    private static Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
            System.out.println("Connected to the database successfully!");
        } catch (SQLException e) {
            System.out.println("Connection failed!");
            e.printStackTrace();
        }
        return connection;
    }

    // Method to get user profile data
    public static void getUserProfile() {
        try {
            // Step 1: Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 2: Create a connection to the database
            Connection connection = getConnection();  // Reusing the getConnection method

            // Step 3: Prepare SQL query
            String sql = "SELECT name, age, gender FROM user_info WHERE username = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, 1);  // Fetching user with ID 1 or modify as per your need

            // Step 4: Execute query and get results
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String name = resultSet.getString("name");
                String username = resultSet.getString("username");  // Email ID in your case
                int age = resultSet.getInt("age");
                String gender = resultSet.getString("gender");

                System.out.println("Name: " + name);
                System.out.println("Username (Email): " + username);
                System.out.println("Age: " + age);
                System.out.println("Gender: " + gender);
            }

            // Step 5: Close connection
            if (connection != null) {
                connection.close();
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        getUserProfile();  // Fetch and display user profile data
    }

    // Method to insert a new user record into the database
    public static void insertRecord(UserDetails userDetails) {
        Connection connection = getConnection();
        PreparedStatement preparedStatement = null;

        String insertSQL = "INSERT INTO user_info (username, name, age, gender, password) VALUES (?, ?, ?, ?, ?)";

        try {
            if (connection != null) {
                preparedStatement = connection.prepareStatement(insertSQL);
                preparedStatement.setString(1, userDetails.getUsername());
                preparedStatement.setString(2, userDetails.getName());
                preparedStatement.setInt(3, userDetails.getAge());
                preparedStatement.setString(4, userDetails.getGender());
                preparedStatement.setString(5, userDetails.getPassword());

                int rowsInserted = preparedStatement.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("A new record was inserted successfully!");
                } else {
                    System.out.println("No record was inserted.");
                }
            } else {
                System.out.println("Failed to establish a connection.");
            }
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.out.println("Failed to close resources: " + e.getMessage());
            }
        }
    }

    // Method to validate user credentials
    public static boolean validateCredentials(String username, String password) {
        Connection connection = getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        String query = "SELECT * FROM user_info WHERE username = ? AND password = ?";

        try {
            if (connection != null) {
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, hashPassword(password));

                resultSet = preparedStatement.executeQuery();

                // Check if any matching record exists
                return resultSet.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    // Method to check if username exists
    public static boolean isUsernameExists(String username) {
        String query = "SELECT COUNT(*) FROM user_info WHERE username = ?";
        try (Connection conn = getConnection(); // Use getConnection method to avoid redundant code
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to check if password exists
    public static boolean isPasswordExists(String password) {
        String hashedPassword = hashPassword(password);
        if (hashedPassword == null) {
            return false;
        }
        String query = "SELECT COUNT(*) FROM user_info WHERE password = ?";
        try (Connection conn = getConnection(); // Use getConnection method to avoid redundant code
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, hashedPassword);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Public method for password hashing
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}