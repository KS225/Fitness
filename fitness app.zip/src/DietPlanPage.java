import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DietPlanPage extends JFrame {

    private JPanel contentPane;
    private JComboBox<String> bmiCategoryComboBox;
    private JTextArea dietPlanArea;

    public DietPlanPage() {
        setTitle("Diet Plans");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 500, 400);

        // Set background color
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(173, 216, 230)); // Light blue background
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title Label
        JLabel lblTitle = new JLabel("Select Your BMI Category for Diet Plans");
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblTitle.setForeground(new Color(0, 0, 255)); // Blue text
        lblTitle.setBounds(80, 20, 350, 30);
        contentPane.add(lblTitle);

        // Dropdown to select BMI category
        bmiCategoryComboBox = new JComboBox<>();
        bmiCategoryComboBox.setBackground(new Color(100, 149, 237));
        bmiCategoryComboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Select..", "Underweight", "Normal Weight", "Overweight", "Obese"}));
        bmiCategoryComboBox.setBounds(150, 60, 200, 30);
        contentPane.add(bmiCategoryComboBox);

        // Text area to display the diet plan
        dietPlanArea = new JTextArea();
        dietPlanArea.setFont(new Font("Cambria", Font.BOLD, 13));
        dietPlanArea.setLineWrap(true);
        dietPlanArea.setWrapStyleWord(true);
        dietPlanArea.setEditable(false);
        dietPlanArea.setBackground(new Color(240, 248, 255)); // Light blue-grey background
        dietPlanArea.setForeground(Color.BLACK); // Black text for better readability

        JScrollPane scrollPane = new JScrollPane(dietPlanArea);
        scrollPane.setBounds(50, 110, 400, 200);
        contentPane.add(scrollPane);

        // Show Diet Plan button
        JButton btnShowDietPlan = new JButton("Show Diet Plan");
        btnShowDietPlan.setBounds(180, 320, 150, 30);
        btnShowDietPlan.setBackground(SystemColor.textHighlight); // Steel Blue color for button
        btnShowDietPlan.setForeground(Color.WHITE); // White text for contrast
        contentPane.add(btnShowDietPlan);

        // Action listener for Show Diet Plan button
        btnShowDietPlan.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedCategory = (String) bmiCategoryComboBox.getSelectedItem();
                displayDietPlan(selectedCategory);
            }
        });
    }

    // Method to display diet plan based on BMI category
    private void displayDietPlan(String category) {
        String dietPlan = "";
        switch (category) {
            case "Select..":
                break;
            case "Underweight":
                dietPlan = getUnderweightDietPlan();
                break;
            case "Normal Weight":
                dietPlan = getNormalWeightDietPlan();
                break;
            case "Overweight":
                dietPlan = getOverweightDietPlan();
                break;
            case "Obese":
                dietPlan = getObeseDietPlan();
                break;
        }
        dietPlanArea.setText(dietPlan);
    }

    // Diet plan for Underweight category
    private String getUnderweightDietPlan() {
        return "Diet Plan for Underweight:\n\n" +
                "- Increase calorie intake with nutrient-dense foods.\n" +
                "- Eat more frequent meals, including healthy snacks.\n" +
                "- Include protein-rich foods like eggs, chicken, and beans.\n" +
                "- Add healthy fats like avocado, nuts, and seeds.\n" +
                "- Most Importantly Stay Hydrated.\n" +
                "- Consider smoothies and shakes with added nutrition.\n";
    }

    // Diet plan for Normal Weight category
    private String getNormalWeightDietPlan() {
        return "Diet Plan for Normal Weight:\n\n" +
                "- Maintain a balanced diet with all food groups.\n" +
                "- Include lean proteins, whole grains, and vegetables.\n" +
                "- Monitor portion sizes to avoid overeating.\n" +
                "- Drink plenty of water and limit sugary drinks.\n" +
                "- Most Importantly Stay Hydrated.\n" +
                "- Incorporate physical activity into your daily routine.\n";
    }

    // Diet plan for Overweight category
    private String getOverweightDietPlan() {
        return "Diet Plan for Overweight:\n\n" +
                "- Focus on whole, unprocessed foods.\n" +
                "- Limit intake of high-calorie, sugary, and fatty foods.\n" +
                "- Increase fiber intake from vegetables, fruits, and legumes.\n" +
                "- Include lean proteins like fish and poultry.\n" +
                "- Avoid snacking and stick to regular meal times.\n" +
                "- Most Importantly Stay Hydrated.\n" +
                "- Consider reducing portion sizes gradually.\n";
    }

    // Diet plan for Obese category
    private String getObeseDietPlan() {
        return "Diet Plan for Obese:\n\n" +
                "- Follow a structured, calorie-controlled meal plan.\n" +
                "- Focus on high-fiber foods like fruits, vegetables, and whole grains.\n" +
                "- Minimize intake of processed foods and sugary drinks.\n" +
                "- Include healthy fats from sources like nuts and olive oil.\n" +
                "- Eat smaller, more frequent meals to avoid hunger.\n" +
                "- Most Importantly Stay Hydrated.\n" +
                "- Consult with a dietitian for a personalized plan.\n";
    }

    // Main method to run the application
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                DietPlanPage frame = new DietPlanPage();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
