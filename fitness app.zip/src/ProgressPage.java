import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class ProgressPage extends JFrame {
    private JTextField waterIntakeField;
    private JCheckBox dailyStreakCheckbox;
    private JLabel streakStatusLabel;
    private JTextArea progressDisplayArea;  // To display date-wise progress

    public ProgressPage() {
        setTitle("Progress Tracker");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 500, 400);
        JPanel contentPane = new JPanel();
        contentPane.setBackground(new Color(173, 216, 230)); // Light blue background
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // Title Label
        JLabel lblTitle = new JLabel("Track Your Progress");
        lblTitle.setForeground(new Color(0, 0, 255));
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblTitle.setBounds(150, 20, 200, 30);
        contentPane.add(lblTitle);

        // Water Intake Label
        JLabel lblWaterIntake = new JLabel("Water Intake (ml):");
        lblWaterIntake.setBounds(50, 80, 120, 30);
        contentPane.add(lblWaterIntake);

        // Water Intake Field
        waterIntakeField = new JTextField();
        waterIntakeField.setBounds(180, 80, 150, 30);
        contentPane.add(waterIntakeField);

        // Daily Streak Checkbox
        dailyStreakCheckbox = new JCheckBox("Mark as Visited");
        dailyStreakCheckbox.setBounds(50, 130, 200, 30);
        contentPane.add(dailyStreakCheckbox);

        // Save Button
        JButton btnSave = new JButton("Save Progress");
        btnSave.setBounds(180, 180, 130, 30);
        contentPane.add(btnSave);

        // Streak Status Label
        streakStatusLabel = new JLabel("");
        streakStatusLabel.setBounds(50, 220, 300, 30);
        streakStatusLabel.setFont(new Font("Tahoma", Font.ITALIC, 12));
        contentPane.add(streakStatusLabel);

        // Progress Display Area
        progressDisplayArea = new JTextArea();
        progressDisplayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(progressDisplayArea);
        scrollPane.setBounds(50, 260, 400, 100); // Larger scroll area for progress display
        contentPane.add(scrollPane);

        // Save Button Action Listener
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveProgress();
                displayProgress();  // Update the progress display after saving
            }
        });

        // Display existing progress on load
        displayProgress();
    }

    // Method to save progress
    private void saveProgress() {
        String waterIntake = waterIntakeField.getText();
        boolean dailyStreakCompleted = dailyStreakCheckbox.isSelected();

        // Simple validation
        if (waterIntake.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your water intake!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get the current date
        String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        // Save progress to file
        try (FileWriter writer = new FileWriter("progress.txt", true)) {
            writer.write(currentDate + " - Water Intake: " + waterIntake + " ml, Daily Streak: " + (dailyStreakCompleted ? "Yes" : "No") + "\n");
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        // Feedback to user
        streakStatusLabel.setText("Progress saved for " + currentDate + "!");

        // Reset the input fields after saving
        waterIntakeField.setText("");
        dailyStreakCheckbox.setSelected(false);
    }

    // Method to display progress date-wise
    private void displayProgress() {
        progressDisplayArea.setText(""); // Clear the previous content
        try (Scanner scanner = new Scanner(new File("progress.txt"))) {
            while (scanner.hasNextLine()) {
                progressDisplayArea.append(scanner.nextLine() + "\n");
            }
        } catch (FileNotFoundException e) {
            progressDisplayArea.setText("No progress data found. Start tracking today!");
        }
    }

    // Main method to launch the ProgressPage
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ProgressPage frame = new ProgressPage();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
