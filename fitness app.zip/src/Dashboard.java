import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Dashboard extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private String username;

    public Dashboard(String uname) {
        this.username = uname;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 700); 

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        JScrollPane scrollPane = new JScrollPane(contentPane);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        setContentPane(scrollPane);

        // Panel 1 - Profile
        JPanel panel1 = new JPanel();
        panel1.setBounds(0, 50, 300, 200);
        panel1.setBackground(new Color(255, 204, 204));
        contentPane.add(panel1);
        panel1.setLayout(null);

        JLabel lblProfile = new JLabel("Profile");
        lblProfile.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblProfile.setHorizontalAlignment(JLabel.CENTER);
        lblProfile.setBounds(0, 10, 300, 30);
        panel1.add(lblProfile);

        JButton btnProfile = createButton("/Images/icon.jpg", e -> openProfilePage());
        btnProfile.setBounds(100, 50, 100, 100);
        panel1.add(btnProfile);

        // Panel 2 - Videos
        JPanel panel2 = new JPanel();
        panel2.setBounds(300, 50, 300, 200);
        panel2.setBackground(new Color(204, 255, 204));
        contentPane.add(panel2);
        panel2.setLayout(null);

        JLabel lblVideos = new JLabel("Videos");
        lblVideos.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblVideos.setHorizontalAlignment(JLabel.CENTER);
        lblVideos.setBounds(0, 10, 300, 30);
        panel2.add(lblVideos);

        JButton btnVideos = createButton("/Images/videos.jpg", e -> openVideosWindow());
        btnVideos.setBounds(100, 50, 100, 100);
        panel2.add(btnVideos);

        // Panel 3 - BMI Calculator
        JPanel panel3 = new JPanel();
        panel3.setBounds(0, 250, 300, 200);
        panel3.setBackground(new Color(204, 204, 255));
        contentPane.add(panel3);
        panel3.setLayout(null);

        JLabel lblBMI = new JLabel("BMI Calculator");
        lblBMI.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblBMI.setHorizontalAlignment(JLabel.CENTER);
        lblBMI.setBounds(0, 10, 300, 30);
        panel3.add(lblBMI);

        JButton btnBMI = createButton("/Images/Calci.jpg", e -> openBMIWindow());
        btnBMI.setBounds(100, 50, 100, 100);
        panel3.add(btnBMI);

        // Panel 4 - Progress
        JPanel panel4 = new JPanel();
        panel4.setBounds(300, 250, 300, 200);
        panel4.setBackground(new Color(255, 255, 204));
        contentPane.add(panel4);
        panel4.setLayout(null);

        JLabel lblProgress = new JLabel("Progress");
        lblProgress.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblProgress.setHorizontalAlignment(JLabel.CENTER);
        lblProgress.setBounds(0, 10, 300, 30);
        panel4.add(lblProgress);

        JButton btnProgress = createButton("/Images/Progress.jpg", e -> showProgressSection());
        btnProgress.setBounds(100, 50, 100, 100);
        panel4.add(btnProgress);

        // Panel 5 - Diet
        JPanel panel5 = new JPanel();
        panel5.setBounds(0, 450, 300, 200);
        panel5.setBackground(new Color(204, 255, 204));
        contentPane.add(panel5);
        panel5.setLayout(null);

        JLabel lblDiet = new JLabel("Diet");
        lblDiet.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblDiet.setHorizontalAlignment(JLabel.CENTER);
        lblDiet.setBounds(0, 10, 300, 30);
        panel5.add(lblDiet);

        JButton btnDiet = createButton("/Images/Diet.png", e -> openDietWindow());
        btnDiet.setBounds(100, 50, 100, 100);
        panel5.add(btnDiet);

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBounds(0, 0, 600, 40);
        contentPane.add(menuBar);

        JMenu mnProfile = new JMenu("");
        mnProfile.setIcon(new ImageIcon(getImageURL("/Images/Dash.jpg")));
        menuBar.add(mnProfile);

        // Info Menu
        JMenuItem mntmInfo = createMenuItem("Info", "/Images/Info.png");
        mnProfile.add(mntmInfo);
        mntmInfo.addActionListener(e -> showInfoDialog());

        // Settings Menu
        JMenu mnSettings = new JMenu("Settings");
        mnSettings.setIcon(new ImageIcon(getImageURL("/Images/Settings.jpg")));
        mnProfile.add(mnSettings);

        // Delete Account Menu Item
        JMenuItem Delacc = createMenuItem("Delete Account", "/Images/bin.jpg");
        mnSettings.add(Delacc);
        Delacc.addActionListener(e -> deleteAccount());

        // Log Out Menu Item
        JMenuItem LogOut = createMenuItem("Log Out", "/Images/save.jpg");
        mnSettings.add(LogOut);
        LogOut.addActionListener(e -> logOut());
    }

    private JButton createButton(String iconPath, ActionListener actionListener) {
        JButton button = new JButton(new ImageIcon(getImageURL(iconPath)));
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.addActionListener(actionListener);
        return button;
    }

    private void showInfoDialog() {
        String info = "Underweight: BMI less than 18.5\n" +
                "  - May indicate malnutrition or underlying health issues.\n" +
                "  - Higher risk of osteoporosis and weakened immune function.\n\n" +
                "Normal Weight: BMI 18.5 to 24.9\n" +
                "  - Generally considered a healthy weight range.\n\n" +
                "Overweight: BMI 25 to 29.9\n" +
                "  - Increases risk of heart disease, type 2 diabetes, and high blood pressure.\n" +
                "  - Lifestyle changes are recommended.\n\n" +
                "Obesity: BMI 30 or higher\n" +
                "  - Significantly raises the risk of serious health conditions.\n" +
                "  - Often linked to metabolic syndrome and requires medical attention.";
        JOptionPane.showMessageDialog(this, info, "BMI Information", JOptionPane.INFORMATION_MESSAGE);
    }

    private JMenuItem createMenuItem(String text, String iconPath) {
        JMenuItem menuItem = new JMenuItem(text);
        URL iconUrl = getImageURL(iconPath);
        if (iconUrl == null) {
            System.err.println("Could not find resource: " + iconPath);
        } else {
            menuItem.setIcon(new ImageIcon(iconUrl));
        }
        return menuItem;
    }

    private URL getImageURL(String path) {
        URL iconUrl = Dashboard.class.getResource(path);
        if (iconUrl == null) {
            System.err.println("Could not find resource: " + path);
        }
        return iconUrl;
    }

    private void openProfilePage() {
        ProfilePage profilePage = new ProfilePage(username);
        profilePage.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        profilePage.setVisible(true);
    }

    private void openBMIWindow() {
        BMI bmiFrame = new BMI(username, this);
        bmiFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        bmiFrame.setVisible(true);
    }

    private void openVideosWindow() {
        Videos videosFrame = new Videos(username);
        videosFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        videosFrame.setVisible(true);
    }

    private void openDietWindow() {
        DietPlanPage dietPage = new DietPlanPage(); // Open the DietPlanPage
        dietPage.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dietPage.setVisible(true);
    }

    private void showProgressSection() {
        ProgressPage progressPage = new ProgressPage(); // Open the ProgressPage
        progressPage.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        progressPage.setVisible(true);
    }

    private void deleteAccount() {
        String inputPassword = JOptionPane.showInputDialog(this, "Enter your password to confirm account deletion:", "Verify Password", JOptionPane.WARNING_MESSAGE);

        if (inputPassword != null && verifyPassword(inputPassword)) {
            int confirmation = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete your account?", "Delete Account", JOptionPane.YES_NO_OPTION);
            if (confirmation == JOptionPane.YES_OPTION) {
                if (deleteUserFromDatabase()) {
                    JOptionPane.showMessageDialog(this, "Account deleted successfully.");
                    dispose(); // Close the dashboard after deletion
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete account. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else if (inputPassword != null) {
            JOptionPane.showMessageDialog(this, "Incorrect password. Account deletion canceled.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean verifyPassword(String inputPassword) {
        boolean isValid = false;
        String query = "SELECT * FROM Users WHERE username = ? AND password = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fitness", "Vrushali", "Vrushali@1220");
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, this.username);
            stmt.setString(2, inputPassword);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                isValid = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error verifying password.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return isValid;
    }

    private boolean deleteUserFromDatabase() {
        boolean isDeleted = false;
        String deleteQuery = "DELETE FROM Users WHERE username = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fitness", "Vrushali", "Vrushali@1220");
             PreparedStatement stmt = conn.prepareStatement(deleteQuery)) {

            stmt.setString(1, this.username);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                isDeleted = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting account.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return isDeleted;
    }

    private void logOut() {
        int confirmation = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Log Out", JOptionPane.YES_NO_OPTION);
        if (confirmation == JOptionPane.YES_OPTION) {
            // Handle log out logic here
            dispose(); // Close the dashboard
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Dashboard frame = new Dashboard("Vrushali"); // Replace with actual username logic
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
