import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class Videos extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private String username;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Videos frame = new Videos("defaultUsername");
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Videos(String username) {
        this.username = username;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 480, 400);
        contentPane = new JPanel();
        contentPane.setBackground(Color.decode("#ffffff")); // Change to a white background
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout());

        // Title
        JLabel titleLabel = new JLabel("Workout Videos", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Cambria", Font.BOLD, 24));
        titleLabel.setForeground(Color.decode("#FF5733")); // Change title color
        contentPane.add(titleLabel, BorderLayout.NORTH);

        // Create a panel to hold the video links
        JPanel contentPanel = new JPanel();
        contentPanel.setBackground(Color.decode("#ffffff")); // Keep content panel white
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        // Video Links
        addVideoLink(contentPanel, "7-MINUTE FULL BODY Workout At Home", "https://youtu.be/5BwlDW0CAuU?si=WvtkdTdT7Bkqbmek");
        addSeparator(contentPanel);
        addVideoLink(contentPanel, "Do This Workout Every Evening - 10 Minute Full Body To Get In Shape", "https://youtu.be/agvdkRc_img?si=5QDPsuLaTglCmaw1");
        addSeparator(contentPanel);
        addVideoLink(contentPanel, "10 MIN MORNING EXERCISE FOR KIDS - ENERGY BOOST WORKOUT", "https://youtube.com/watch?v=Wj9SvxCpA4o&feature=shared");
        addSeparator(contentPanel);
        addVideoLink(contentPanel, "15 Min Stretching: Total Body Flexibility and Warm Up", "https://youtu.be/i7LJ-39bFgE?si=xjTa50Pp0tsvQ9tr");

        // Wrap the content panel in a JScrollPane
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder()); // Remove border for scroll pane

        // Back button
        JButton btnBack = createBackButton();
        contentPane.add(btnBack, BorderLayout.SOUTH);
        contentPane.add(scrollPane, BorderLayout.CENTER);
    }

    private void addVideoLink(JPanel panel, String text, String url) {
        JLabel videoLabel = new JLabel(text);
        videoLabel.setFont(new Font("Cambria", Font.PLAIN, 18));
        videoLabel.setForeground(Color.decode("#007BFF")); // Link color
        videoLabel.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Hand cursor on hover
        videoLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                openWebpage(url);
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                videoLabel.setForeground(Color.decode("#0056b3")); // Darken on hover
            }
            @Override
            public void mouseExited(MouseEvent e) {
                videoLabel.setForeground(Color.decode("#007BFF")); // Reset to original color
            }
        });
        panel.add(videoLabel);
    }

    private void addSeparator(JPanel panel) {
        JSeparator separator = new JSeparator();
        separator.setBackground(Color.LIGHT_GRAY);
        panel.add(separator);
    }

    private JButton createBackButton() {
        JButton btnBack = new JButton("BACK");
        btnBack.setFont(new Font("Cambria", Font.BOLD, 16));
        btnBack.setForeground(Color.WHITE);
        btnBack.setBackground(Color.decode("#FF5733")); // Change button background color
        btnBack.setBorder(new LineBorder(Color.decode("#C70039"), 2, true)); // Change border color
        btnBack.setFocusPainted(false);
        btnBack.setOpaque(true);
        btnBack.addActionListener(e -> {
            Dashboard dashboardFrame = new Dashboard(username); // Use the passed username
            dashboardFrame.setVisible(true);
            dispose(); // Close current frame
        });
        btnBack.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btnBack.setBackground(Color.decode("#C70039")); // Darken on hover
            }
            public void mouseExited(MouseEvent evt) {
                btnBack.setBackground(Color.decode("#FF5733")); // Reset to original color
            }
        });
        return btnBack;
    }

    private void openWebpage(String url) {
        try {
            Desktop desktop = Desktop.getDesktop();
            URI uri = new URI(url);
            if (Desktop.isDesktopSupported() && desktop.isSupported(Desktop.Action.BROWSE)) {
                desktop.browse(uri);
            }
        } catch (IOException | URISyntaxException ex) {
            ex.printStackTrace();
        }
    }
}