import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProfilePage extends JFrame {
    private String username; // To store the username
    private JLabel userNameLabel;
    private JLabel emailLabel; // Email label declaration
    private JLabel ageLabel; // Label for age
    private JLabel genderLabel; // Label for gender
    private JLabel profilePictureLabel; // Label to display profile picture
    private JButton uploadButton; // Button to upload profile picture
    private JButton editProfileButton; // Button to edit profile
    private JButton logoutButton; // Button to log out
    private JButton backButton; // Button to go back to dashboard

    public ProfilePage(String username) {
        this.username = username; // Initialize with the passed username

        // Frame properties
        setTitle("User Profile");
        setSize(300, 450); // Slightly larger size for better layout
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(240, 240, 240)); // Light background color

        // Main Panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(new Color(255, 255, 255)); // White background for the main panel
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add padding

        // User Info Panel
        JPanel userInfoPanel = new JPanel();
        SpringLayout sl_userInfoPanel = new SpringLayout();
        userInfoPanel.setLayout(sl_userInfoPanel);
        userInfoPanel.setBackground(new Color(255, 255, 255)); // White background

        // Profile Picture Label
        profilePictureLabel = new JLabel(new ImageIcon(new ImageIcon("default.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH)), SwingConstants.CENTER); // Default image
        profilePictureLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        profilePictureLabel.setPreferredSize(new Dimension(80, 80)); // Small square size
        profilePictureLabel.setOpaque(true);
        profilePictureLabel.setBackground(Color.WHITE);

        // Button to upload profile picture
        uploadButton = new JButton("Upload");
        uploadButton.setBackground(new Color(100, 149, 237)); // Cornflower Blue
        uploadButton.setForeground(Color.WHITE);
        uploadButton.setFocusPainted(false);
        uploadButton.addActionListener(e -> uploadProfilePicture());

        // Add components to user info panel
        userInfoPanel.add(profilePictureLabel);
        userInfoPanel.add(uploadButton);

        // User Details (Name, Email, Age, and Gender)
        userNameLabel = new JLabel("Name: ", SwingConstants.LEFT);
        emailLabel = new JLabel("Email: ", SwingConstants.LEFT);
        ageLabel = new JLabel("Age: ", SwingConstants.LEFT);
        genderLabel = new JLabel("Gender: ", SwingConstants.LEFT);

        // Add user detail labels to the user info panel
        userInfoPanel.add(userNameLabel);
        userInfoPanel.add(emailLabel);
        userInfoPanel.add(ageLabel);
        userInfoPanel.add(genderLabel);

        // Setting layout constraints for user info panel
        sl_userInfoPanel.putConstraint(SpringLayout.NORTH, profilePictureLabel, 10, SpringLayout.NORTH, userInfoPanel);
        sl_userInfoPanel.putConstraint(SpringLayout.WEST, profilePictureLabel, 10, SpringLayout.WEST, userInfoPanel);
        sl_userInfoPanel.putConstraint(SpringLayout.NORTH, uploadButton, 6, SpringLayout.SOUTH, profilePictureLabel);
        sl_userInfoPanel.putConstraint(SpringLayout.EAST, uploadButton, -10, SpringLayout.EAST, userInfoPanel);
        sl_userInfoPanel.putConstraint(SpringLayout.NORTH, userNameLabel, 20, SpringLayout.SOUTH, uploadButton);
        sl_userInfoPanel.putConstraint(SpringLayout.WEST, userNameLabel, 10, SpringLayout.WEST, userInfoPanel);
        sl_userInfoPanel.putConstraint(SpringLayout.NORTH, emailLabel, 10, SpringLayout.SOUTH, userNameLabel);
        sl_userInfoPanel.putConstraint(SpringLayout.WEST, emailLabel, 10, SpringLayout.WEST, userInfoPanel);
        sl_userInfoPanel.putConstraint(SpringLayout.NORTH, ageLabel, 10, SpringLayout.SOUTH, emailLabel);
        sl_userInfoPanel.putConstraint(SpringLayout.WEST, ageLabel, 10, SpringLayout.WEST, userInfoPanel);
        sl_userInfoPanel.putConstraint(SpringLayout.NORTH, genderLabel, 10, SpringLayout.SOUTH, ageLabel);
        sl_userInfoPanel.putConstraint(SpringLayout.WEST, genderLabel, 10, SpringLayout.WEST, userInfoPanel);

        // Adding user info panel to the main panel
        mainPanel.add(userInfoPanel);

        // Buttons Panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new FlowLayout());
        buttonsPanel.setBackground(new Color(240, 240, 240)); // Light background
        mainPanel.add(buttonsPanel);

        // Create buttons
        editProfileButton = new JButton("Edit Name");
        logoutButton = new JButton("Logout");
        backButton = new JButton("Back");

        // Button styles
        editProfileButton.setBackground(new Color(100, 149, 237)); // Cornflower Blue
        logoutButton.setBackground(Color.RED);
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        backButton.setBackground(new Color(100, 149, 237)); // Cornflower Blue

        // Add buttons to the buttons panel
        buttonsPanel.add(editProfileButton);
        buttonsPanel.add(backButton);
        buttonsPanel.add(logoutButton);

        // Action listeners for buttons
        editProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newName = JOptionPane.showInputDialog("Enter new name:");
                if (newName != null && !newName.trim().isEmpty()) {
                    updateUserProfile(newName);
                }
            }
        });

        // Enhanced logout action listener
        logoutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Log Out", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(this, "Logged out successfully!");
                // Assuming you have a LoginProfile class to redirect after logout
                LoginProfile loginPage = new LoginProfile(); // Assuming LoginProfile is another class
                loginPage.setVisible(true); // Show the login page
                dispose(); // Close the profile window
            }
        });

        // Add action listener for back button
        backButton.addActionListener(e -> {
            Dashboard dashboard = new Dashboard(username); // Create a new instance of Dashboard
            dashboard.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Ensure only the dashboard closes
            dashboard.setVisible(true); // Show the dashboard
            dispose(); // Close the profile page
        });

        // Adding main panel to frame
        getContentPane().add(mainPanel, BorderLayout.CENTER);

        // Load user data from database
        loadUserData();
    }

    // Method to update user profile name in the database
    private void updateUserProfile(String newName) {
        String url = "jdbc:mysql://localhost:3306/fitness"; // Update with your database URL
        String user = "Vrushali"; // Update with your database username
        String password = "Vrushali@1220"; // Update with your database password

        String query = "UPDATE user_info SET name = ? WHERE username = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, newName);
            pstmt.setString(2, username);
            pstmt.executeUpdate();

            userNameLabel.setText("Name: " + newName); // Update the label with the new name
            JOptionPane.showMessageDialog(this, "Profile updated successfully.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to allow the user to upload a profile picture
    private void uploadProfilePicture() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Choose Profile Picture");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image Files", "jpg", "png", "jpeg"));

        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String profilePicPath = selectedFile.getAbsolutePath();

            // Set the profile picture label with the selected image
            ImageIcon profileImage = new ImageIcon(new ImageIcon(profilePicPath).getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH)); // Small square size
            profilePictureLabel.setIcon(profileImage);
        }
    }

    private void loadUserData() {
        String url = "jdbc:mysql://localhost:3306/fitness"; // Update with your database URL
        String user = "Vrushali"; // Update with your database username
        String password = "Vrushali@1220"; // Update with your database password

        String query = "SELECT name, age, gender FROM user_info WHERE username = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // Assuming the result set columns correspond to your database structure
                String name = rs.getString("name");
                String email = username; // Since username is email
                int age = rs.getInt("age"); // Retrieve age
                String gender = rs.getString("gender"); // Retrieve gender

                // Update labels with user data
                userNameLabel.setText("Name: " + name);
                emailLabel.setText("Email: " + email);
                ageLabel.setText("Age: " + age); // Update age label
                genderLabel.setText("Gender: " + gender); // Update gender label
            } else {
                JOptionPane.showMessageDialog(this, "User not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        ProfilePage profilePage = new ProfilePage("john.doe@example.com"); // Use a sample username for testing
        profilePage.setVisible(true);
    }
}