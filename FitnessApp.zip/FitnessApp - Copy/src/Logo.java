import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.border.EmptyBorder;

public class Logo extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblNewLabel;
    private JLabel fitnessNoteLabel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Logo frame = new Logo();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Logo() {
        // Basic frame settings
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 396, 471); // Adjusted size to 396 x 471
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null); // Using null layout for absolute positioning

        // Array of fitness-related notes
        String[] fitnessNotes = {
            "Stay hydrated throughout the day!",
            "Consistency is the key to fitness success.",
            "A healthy mind lives in a healthy body.",
            "Exercise regularly for a stronger immune system.",
           
        };

        // Randomly select a fitness note to display
        Random random = new Random();
        int randomIndex = random.nextInt(fitnessNotes.length);

        // Create the fitness note label
        fitnessNoteLabel = new JLabel(fitnessNotes[randomIndex]); // Set a random fitness note
        fitnessNoteLabel.setHorizontalAlignment(SwingConstants.CENTER);
        fitnessNoteLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
        fitnessNoteLabel.setForeground(Color.BLACK); // Set text color to black for visibility
        fitnessNoteLabel.setBounds(0, 372, 396, 62); // Position at the bottom on top of the logo
        fitnessNoteLabel.setOpaque(false); // Make sure the background is transparent
        contentPane.add(fitnessNoteLabel); // Add the fitness note label on top of the logo
        
        // Load the logo image
        lblNewLabel = new JLabel("");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 8));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(0, -31, 396, 455); // Cover the top part of the panel
        contentPane.add(lblNewLabel); // Add the logo to the content pane

        // Set the logo image after all components are added
        setLogoImage(); // Method to set and scale the logo image

        // Timer to transition to LoginProfile after 3 seconds
        Timer timer = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create and show the LoginProfile window
                LoginProfile loginProfile = new LoginProfile();
                loginProfile.setVisible(true);
                // Close the current Logo window
                dispose();
            }
        });
        timer.setRepeats(false); // Only execute once
        timer.start(); // Start the timer
    }

    private void setLogoImage() {
        // Load the image (update the path as needed)
        ImageIcon logoIcon = new ImageIcon("src/images/img1.png"); // Replace with the correct path
        Image img = logoIcon.getImage(); // Transform it
        Image scaledImg = img.getScaledInstance(396, 380, Image.SCALE_SMOOTH); // Adjust height for note
        lblNewLabel.setIcon(new ImageIcon(Logo.class.getResource("/Images/img1.jpg"))); // Set the scaled image to the label
    }

    public ImageIcon getLogo() {
        return (ImageIcon) lblNewLabel.getIcon();
    }

    public void setLogo(ImageIcon icon) {
        lblNewLabel.setIcon(icon);
    }
}