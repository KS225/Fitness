import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class BMI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textFieldWeight, textFieldHeight, textFieldAge, textFieldBMI;
    private JTextField textFieldStatus;
    private String gender;
    private String username;
    private Dashboard dashboard; 

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BMI frame = new BMI("defaultUsername", null);
            frame.setVisible(true);
        });
    }

    public BMI(String username, Dashboard dashboard) {
        this.username = username;
        this.dashboard = dashboard;

        setTitle("BMI Calculator");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 520);
        setLocationRelativeTo(null); // Center window
        setResizable(false);

        // Gradient background
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, new Color(240, 250, 255),
                        0, getHeight(), new Color(200, 230, 255));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                g2d.dispose();
            }
        };
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // Title
        JLabel lblTitle = new JLabel("Know Your BMI", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(new Color(0, 102, 204));
        lblTitle.setBounds(50, 20, 400, 40);
        contentPane.add(lblTitle);

        // Gender
     
        JLabel lblGender = new JLabel("Your Gender:");
        lblGender.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblGender.setBounds(25, 80, 120, 25); // Slightly above weight
        contentPane.add(lblGender);

        // Male radio button
        JRadioButton rdbtnMale = new JRadioButton("Male");
        rdbtnMale.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        rdbtnMale.setBounds(150, 80, 70, 25); // next to label
        contentPane.add(rdbtnMale);

        // Female radio button
        JRadioButton rdbtnFemale = new JRadioButton("Female");
        rdbtnFemale.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        rdbtnFemale.setBounds(230, 80, 80, 25); // next to male button
        contentPane.add(rdbtnFemale);

        // Group radio buttons
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(rdbtnMale);
        genderGroup.add(rdbtnFemale);
        rdbtnMale.setOpaque(false);
        rdbtnFemale.setOpaque(false);

        // Weight
        JLabel lblWeight = new JLabel("Weight (Kg):");
        lblWeight.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblWeight.setBounds(50, 120, 120, 25);
        contentPane.add(lblWeight);

        textFieldWeight = createTextField(180, 120, 200, 25);
        contentPane.add(textFieldWeight);

        // Height
        JLabel lblHeight = new JLabel("Height (cm):");
        lblHeight.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblHeight.setBounds(50, 160, 120, 25);
        contentPane.add(lblHeight);

        textFieldHeight = createTextField(180, 160, 200, 25);
        contentPane.add(textFieldHeight);

        // Age
        JLabel lblAge = new JLabel("Age:");
        lblAge.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblAge.setBounds(50, 200, 120, 25);
        contentPane.add(lblAge);

        textFieldAge = createTextField(180, 200, 200, 25);
        contentPane.add(textFieldAge);

        // Check button
        JButton btnCheck = createButton("Check", 120, 250, 100, 40, new Color(0, 153, 102));
        btnCheck.addActionListener(e -> calculateBMI(rdbtnMale, rdbtnFemale));
        contentPane.add(btnCheck);

        // Clear button
        JButton btnClear = createButton("Clear", 260, 250, 100, 40, new Color(204, 0, 0));
        btnClear.addActionListener(e -> clearFields(genderGroup));
        contentPane.add(btnClear);

        // BMI Output
        JLabel lblBMI = new JLabel("BMI:");
        lblBMI.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblBMI.setBounds(50, 320, 50, 25);
        contentPane.add(lblBMI);

        textFieldBMI = createTextField(100, 320, 120, 25);
        textFieldBMI.setEditable(false);
        contentPane.add(textFieldBMI);

        // Status
        JLabel lblStatusLabel = new JLabel("Status:");
        lblStatusLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblStatusLabel.setBounds(50, 360, 60, 25);
        contentPane.add(lblStatusLabel);

        textFieldStatus = new JTextField();
        textFieldStatus.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 16));
        textFieldStatus.setBounds(120, 360, 260, 25);
        textFieldStatus.setEditable(false);
        textFieldStatus.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(150,150,150)),
                BorderFactory.createEmptyBorder(5,5,5,5)
        ));
        contentPane.add(textFieldStatus);

        // Back button
        JButton btnBack = createButton("Back", 180, 410, 120, 40, new Color(0, 102, 204));
        btnBack.addActionListener(e -> {
            if (dashboard != null) dashboard.setVisible(true);
            dispose();
        });
        contentPane.add(btnBack);
    }

    private JTextField createTextField(int x, int y, int w, int h) {
        JTextField tf = new JTextField();
        tf.setBounds(x, y, w, h);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(150,150,150)),
                BorderFactory.createEmptyBorder(5,5,5,5)
        ));
        return tf;
    }

    private JButton createButton(String text, int x, int y, int w, int h, Color color) {
        JButton btn = new JButton(text);
        btn.setBounds(x, y, w, h);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setForeground(Color.WHITE);
        btn.setBackground(color);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder());
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        return btn;
    }

    private void calculateBMI(JRadioButton male, JRadioButton female) {
        try {
            if (textFieldWeight.getText().trim().isEmpty() ||
                textFieldHeight.getText().trim().isEmpty() ||
                textFieldAge.getText().trim().isEmpty() ||
                (!male.isSelected() && !female.isSelected())) {
                textFieldStatus.setText("All fields are required.");
                textFieldStatus.setForeground(Color.RED);
                return;
            }

            double weight = Double.parseDouble(textFieldWeight.getText());
            double height = Double.parseDouble(textFieldHeight.getText()) / 100;
            int age = Integer.parseInt(textFieldAge.getText());
            gender = male.isSelected() ? "Male" : "Female";

            double bmi = weight / (height * height);
            textFieldBMI.setText(String.format("%.2f", bmi));

            String status = getBMICategory(age, bmi, gender);
            textFieldStatus.setText(status);

            if (status.toLowerCase().contains("normal"))
                textFieldStatus.setForeground(new Color(0, 153, 51));
            else if (status.toLowerCase().contains("underweight") || status.toLowerCase().contains("overweight"))
                textFieldStatus.setForeground(new Color(255, 140, 0));
            else
                textFieldStatus.setForeground(new Color(204, 0, 0));

        } catch (NumberFormatException ex) {
            textFieldStatus.setText("Invalid input!");
            textFieldStatus.setForeground(Color.RED);
        }
    }

    private void clearFields(ButtonGroup genderGroup) {
        textFieldWeight.setText("");
        textFieldHeight.setText("");
        textFieldAge.setText("");
        textFieldBMI.setText("");
        textFieldStatus.setText("");
        genderGroup.clearSelection();
    }

    private String getBMICategory(int age, double bmi, String gender) {
        if (age < 18) {
            if (bmi < 15) return "Oops!! You are Underweight.";
            if (bmi < 20) return "Yippie!! You have a normal weight.";
            if (bmi < 25) return "Oops!! You are Overweight.";
            return "Oops!! You are Obese.";
        } else {
            if (gender.equals("Male")) {
                if (bmi < 18.5) return "Oops!! You are Underweight.";
                if (bmi < 24.9) return "Yippie!! You have a normal weight.";
                if (bmi < 29.9) return "Oops!! You are Overweight.";
                return "Oops!! You are Obese.";
            } else {
                if (bmi < 18.5) return "Oops!! You are Underweight.";
                if (bmi < 24.9) return "Yippie!! You have a normal weight.";
                if (bmi < 29.9) return "Oops!! You are Overweight.";
                return "Oops!! You are Obese.";
            }
        }
    }
}
