import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;

public class LoginProfile extends JDialog {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField userField;
    private JPasswordField passwordField;
    private JCheckBox showPasswordCheckBox; // Add this line

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                LoginProfile dialog = new LoginProfile();
                dialog.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public LoginProfile() {
        // Set up the dialog
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setModal(true); // Make it modal
        setAlwaysOnTop(true); // Ensure the dialog stays on top
        setBounds(100, 100, 607, 530); // Adjusted size
        contentPane = new JPanel();
        contentPane.setBackground(new Color(220, 228, 241)); // Softer background color
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Panel with border for layout
        JPanel borderPanel = new JPanel();
        borderPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 120, 215), 2)); // Blue border
        borderPanel.setBounds(98, 36, 378, 435); // Adjusted bounds for border panel
        contentPane.add(borderPanel);
        borderPanel.setLayout(null);

        // Panel for login form
        JPanel loginPanel = new JPanel();
        loginPanel.setBounds(27, 25, 316, 381); // Adjusted height
        loginPanel.setBorder(BorderFactory.createEtchedBorder()); // Softer etched border
        loginPanel.setBackground(Color.WHITE); // White background for clarity
        borderPanel.add(loginPanel);
        loginPanel.setLayout(null);

        // Label for login heading
        JLabel loginLabel = new JLabel("LOGIN");
        loginLabel.setHorizontalAlignment(SwingConstants.CENTER);
        loginLabel.setFont(new Font("Segoe UI Semibold", Font.BOLD, 26)); // Modern font and size
        loginLabel.setBounds(32, 10, 255, 34);
        loginPanel.add(loginLabel);

        // Label and field for username/email
        JLabel usernameLabel = new JLabel("USERNAME/EMAIL ID :");
        usernameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14)); // Updated font for labels
        usernameLabel.setBounds(11, 78, 160, 22);
        loginPanel.add(usernameLabel);

        userField = new JTextField();
        userField.setColumns(10);
        userField.setFont(new Font("Segoe UI", Font.PLAIN, 13)); // Updated font for fields
        userField.setBounds(10, 101, 298, 25);
        loginPanel.add(userField);

        // Label and field for password
        JLabel passwordLabel = new JLabel("PASSWORD :");
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        passwordLabel.setBounds(10, 147, 110, 22);
        loginPanel.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        passwordField.setBounds(10, 174, 297, 25);
        loginPanel.add(passwordField);

        // Checkbox for show password
        showPasswordCheckBox = new JCheckBox("Show Password");
        showPasswordCheckBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        showPasswordCheckBox.setBounds(10, 205, 130, 25); // Adjust position
        showPasswordCheckBox.addActionListener(e -> {
            if (showPasswordCheckBox.isSelected()) {
                passwordField.setEchoChar((char) 0); // Show password
            } else {
                passwordField.setEchoChar('*'); // Hide password
            }
        });
        loginPanel.add(showPasswordCheckBox); // Add checkbox to panel

        // Button to log in with validation
        JButton loginButton = new JButton("LOG IN");
        loginButton.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();

            // Validate fields
            if (username.isEmpty()) {
                JOptionPane.showMessageDialog(LoginProfile.this, "Username/Email ID is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (password.isEmpty()) {
                JOptionPane.showMessageDialog(LoginProfile.this, "Password is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Validate credentials (Assuming Conn.validateCredentials is defined elsewhere)
            if (Conn.validateCredentials(username, password)) {
                Dashboard dashboardFrame = new Dashboard(username);
                dashboardFrame.setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(LoginProfile.this, "Invalid username or password.", "Login Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        loginButton.setFont(new Font("Segoe UI Semibold", Font.BOLD, 15));
        loginButton.setBackground(new Color(0, 120, 215)); // Blue button background
        loginButton.setForeground(Color.WHITE); // White text on button
        loginButton.setBounds(100, 240, 120, 30); // Adjusted button position
        loginPanel.add(loginButton);

        // Button to navigate to sign-up
        JButton signupButton = new JButton("New Here? Sign Up");
        signupButton.addActionListener(e -> {
            Profile profileFrame = new Profile();
            profileFrame.setVisible(true); // Make the Profile frame visible
            profileFrame.setLocationRelativeTo(this); // Center the Profile frame relative to the current dialog

            profileFrame.addWindowListener(new java.awt.event.WindowAdapter() {
                public void windowOpened(java.awt.event.WindowEvent e) {
                    profileFrame.requestFocus(); // Request focus when the window opens
                }
            });

            this.dispose(); // Dispose the current LoginProfile dialog
        });

        signupButton.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        signupButton.setBounds(32, 299, 255, 25);
        signupButton.setForeground(new Color(0, 120, 215)); // Blue text for sign-up
        loginPanel.add(signupButton);

        // Background image
        JLabel bgImg = new JLabel("");
        bgImg.setIcon(null);
        bgImg.setBounds(0, 0, 396, 471); // Adjust bounds to match the frame size
        contentPane.add(bgImg);
    }
}
        
