import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class Calci extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private final JLabel lblTitle = new JLabel("Know Your BMI");
    private JTextField textFieldWeight;
    private JTextField textFieldHeight;
    private JTextField textFieldAge;
    private JLabel lblStatus;
    private JTextField textFieldBMI;
    private JTextField textFieldStatus;
    private ButtonGroup genderGroup;
    private double weight = 0.0d, height = 0.0d, bmi = 0.0d;
    protected int age;
    private JRadioButton rdbtnNewRadioButton;
    private JRadioButton rdbtnFemale;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                // Set the Look and Feel to Nimbus for a modern UI
                UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
                Calci frame = new Calci();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Calci() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 461, 492);
        contentPane = new JPanel();
        contentPane.setBackground(Color.decode("#f4f6f8")); // Light background
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title Label
        lblTitle.setBounds(120, 25, 280, 41);
        lblTitle.setFont(new Font("Cambria", Font.BOLD, 28));
        lblTitle.setForeground(Color.decode("#007BFF")); // Title color
        contentPane.add(lblTitle);

        // Weight Label
        JLabel lblWeight = createLabel("Your Weight (Kg) :", 25, 131);
        contentPane.add(lblWeight);

        // Height Label
        JLabel lblHeight = createLabel("Your Height (cm) :", 25, 182);
        contentPane.add(lblHeight);

        // Age Label
        JLabel lblAge = createLabel("Your Age :", 55, 229);
        contentPane.add(lblAge);

        // TextFields for input
        textFieldWeight = createTextField(182, 140);
        textFieldHeight = createTextField(182, 183);
        textFieldAge = createTextField(182, 230);
        contentPane.add(textFieldWeight);
        contentPane.add(textFieldHeight);
        contentPane.add(textFieldAge);

        // Check Button
        JButton btnCheck = createButton("Check", 120, 270);
        btnCheck.setBackground(new Color(0, 204, 102));
        btnCheck.addActionListener(e -> calculateBMI());
        contentPane.add(btnCheck);

        // Clear Button
        JButton btnClear = createButton("Clear", 227, 270);
        btnClear.setBackground(new Color(204, 0, 0)); 
        btnClear.addActionListener(e -> clearFields());
        contentPane.add(btnClear);

        // Next Button
        JButton btnNext = createButton("Next", 350, 10);
        btnNext.setBackground(new Color(0, 102, 204));
        btnNext.addActionListener(e -> {
            LoginProfile loginFrame = new LoginProfile();
            loginFrame.setVisible(true);
            dispose();
        });
        contentPane.add(btnNext);

        // BMI Label
        JLabel lblBMI = createLabel("Your BMI :", 25, 331);
        contentPane.add(lblBMI);

        // BMI Display Field
        textFieldBMI = createReadOnlyTextField(127, 332);
        contentPane.add(textFieldBMI);

        // Status Label
        lblStatus = createLabel("Status :", 28, 389);
        contentPane.add(lblStatus);

        // Status Display Field
        textFieldStatus = createReadOnlyTextField(111, 390);
        contentPane.add(textFieldStatus);

        // Gender Label
        JLabel lblGender = createLabel("Gender :", 36, 97);
        contentPane.add(lblGender);

        // Gender Radio Buttons
        genderGroup = new ButtonGroup();
        rdbtnNewRadioButton = createRadioButton("Male", 154, 97);
        rdbtnFemale = createRadioButton("Female", 262, 97);
        genderGroup.add(rdbtnNewRadioButton);
        genderGroup.add(rdbtnFemale);
        contentPane.add(rdbtnNewRadioButton);
        contentPane.add(rdbtnFemale);
    }

    private JLabel createLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Cambria", Font.BOLD, 18));
        label.setBounds(x, y, 162, 41);
        label.setForeground(Color.decode("#343A40")); // Label color
        return label;
    }

    private JTextField createTextField(int x, int y) {
        JTextField textField = new JTextField();
        textField.setFont(new Font("Cambria", Font.BOLD, 16));
        textField.setBounds(x, y, 190, 24);
        textField.setBorder(createRoundedBorder());
        return textField;
    }

    private JTextField createReadOnlyTextField(int x, int y) {
        JTextField textField = new JTextField();
        textField.setBackground(Color.decode("#e9ecef")); // Background color for read-only
        textField.setFont(new Font("Cambria", Font.BOLD, 16));
        textField.setColumns(10);
        textField.setBounds(x, y, 190, 31);
        textField.setEditable(false); // Make it read-only
        textField.setBorder(createRoundedBorder());
        return textField;
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBackground(Color.decode("#007BFF")); // Button background color
        button.setForeground(Color.WHITE); // Button text color
        button.setFont(new Font("Cambria", Font.BOLD, 20));
        button.setBounds(x, y, 97, 51);
        button.setBorder(createRoundedBorder());
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(Color.decode("#0056b3")); // Darken on hover
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(Color.decode("#007BFF")); // Reset to original color
            }
        });
        return button;
    }

    private JRadioButton createRadioButton(String text, int x, int y) {
        JRadioButton radioButton = new JRadioButton(text);
        radioButton.setBackground(Color.decode("#f4f6f8")); // Same as contentPane
        radioButton.setFont(new Font("Cambria", Font.BOLD, 18));
        radioButton.setBounds(x, y, 110, 24);
        return radioButton;
    }

    private Border createRoundedBorder() {
        return new LineBorder(Color.decode("#007BFF"), 2, true); // Rounded border
    }

    private void calculateBMI() {
        try {
            // Validate required fields
            if (textFieldWeight.getText().trim().isEmpty() ||
                textFieldHeight.getText().trim().isEmpty() ||
                textFieldAge.getText().trim().isEmpty()) {
                
                textFieldStatus.setText("All fields are required.");
                return;
            }

            age = Integer.parseInt(textFieldAge.getText());
            weight = Double.parseDouble(textFieldWeight.getText());
            height = Double.parseDouble(textFieldHeight.getText());

            height = height / 100;
            if (height <= 0 || weight <= 0 || age <= 0) {
                textFieldStatus.setText("Invalid input");
                return;
            }

            bmi = weight / (height * height);
            textFieldBMI.setText(String.format("%.2f", bmi));

            String status = getBMICategory(age, bmi);
            textFieldStatus.setText(status);
        } catch (NumberFormatException e) {
            textFieldStatus.setText("Invalid number format");
        }
    }

    private String getBMICategory(int age, double bmi) {
        if (bmi < 18.5) {
            return "Underweight";
        } else if (bmi < 24.9) {
            return "Normal weight";
        } else if (bmi < 29.9) {
            return "Overweight";
        } else {
            return "Obesity";
        }
    }

    private void clearFields() {
        textFieldWeight.setText("");
        textFieldHeight.setText("");
        textFieldAge.setText("");
        textFieldBMI.setText("");
        textFieldStatus.setText("");
        genderGroup.clearSelection();
    }
        }