import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class ProgressPage extends JFrame {
    private JTextField waterIntakeField;
    private JCheckBox dailyStreakCheckbox;
    private JLabel streakStatusLabel;
    private JTable progressTable;
    private DefaultTableModel tableModel;

    private JLabel lblTotalEntries;
    private JLabel lblTotalIntake;
    private JLabel lblStreakCount;

    public ProgressPage() {
        setTitle("💧 Water Intake Tracker");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setMinimumSize(new Dimension(700, 500));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // --- Title ---
        JLabel lblTitle = new JLabel("💧 Track Your Daily Water Intake", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(new Color(0, 70, 140));
        lblTitle.setBorder(new EmptyBorder(10, 0, 10, 0));
        add(lblTitle, BorderLayout.NORTH);

        // --- Input Panel ---
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(Color.WHITE);
        inputPanel.setBorder(new CompoundBorder(
                new TitledBorder(new LineBorder(new Color(100, 149, 237), 2, true),
                        "Enter Today's Data", TitledBorder.LEADING, TitledBorder.TOP,
                        new Font("Segoe UI", Font.BOLD, 14), new Color(0, 70, 140)),
                new EmptyBorder(10, 10, 10, 10)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblWaterIntake = new JLabel("Water Intake (ml):");
        lblWaterIntake.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0; gbc.gridy = 0;
        inputPanel.add(lblWaterIntake, gbc);

        waterIntakeField = new JTextField();
        waterIntakeField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 1; gbc.gridy = 0;
        inputPanel.add(waterIntakeField, gbc);

        dailyStreakCheckbox = new JCheckBox("Mark as Visited");
        dailyStreakCheckbox.setBackground(Color.WHITE);
        dailyStreakCheckbox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        inputPanel.add(dailyStreakCheckbox, gbc);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnPanel.setBackground(Color.WHITE);

        JButton btnSave = new JButton("Save Progress");
        styleButton(btnSave);
        JButton btnClear = new JButton("Clear Data");
        styleButton(btnClear);

        btnPanel.add(btnSave);
        btnPanel.add(btnClear);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        inputPanel.add(btnPanel, gbc);

        streakStatusLabel = new JLabel("", SwingConstants.CENTER);
        streakStatusLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        inputPanel.add(streakStatusLabel, gbc);

        add(inputPanel, BorderLayout.NORTH);

        // --- Table Panel ---
        String[] columns = {"Date", "Water Intake (ml)", "Daily Streak"};
        tableModel = new DefaultTableModel(columns, 0);
        progressTable = new JTable(tableModel);
        progressTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        progressTable.setRowHeight(24);
        progressTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        progressTable.getTableHeader().setBackground(new Color(100, 149, 237));
        progressTable.getTableHeader().setForeground(Color.WHITE);
        progressTable.setGridColor(new Color(200, 200, 200));

        progressTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                String streak = (table.getValueAt(row, 2) != null) ? table.getValueAt(row, 2).toString() : "";
                if ("Yes".equalsIgnoreCase(streak)) {
                    c.setBackground(new Color(200, 255, 200));
                } else if ("No".equalsIgnoreCase(streak)) {
                    c.setBackground(new Color(255, 200, 200));
                } else {
                    c.setBackground(Color.WHITE);
                }
                if (isSelected) c.setBackground(new Color(135, 206, 250));
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(progressTable);
        scrollPane.setBorder(new TitledBorder(new LineBorder(new Color(100, 149, 237), 2),
                "Progress History", TitledBorder.LEADING, TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 14), new Color(0, 70, 140)));

        // --- Summary Panel ---
        JPanel summaryPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        summaryPanel.setBackground(new Color(230, 245, 255));
        summaryPanel.setBorder(new CompoundBorder(
                new TitledBorder(new LineBorder(new Color(100, 149, 237), 2, true),
                        "Summary", TitledBorder.LEADING, TitledBorder.TOP,
                        new Font("Segoe UI", Font.BOLD, 14), new Color(0, 70, 140)),
                new EmptyBorder(10, 10, 10, 10)
        ));

        lblTotalEntries = new JLabel("Total Entries: 0", SwingConstants.CENTER);
        lblTotalIntake = new JLabel("Total Intake: 0 ml", SwingConstants.CENTER);
        lblStreakCount = new JLabel("Streak Count: 0", SwingConstants.CENTER);
        lblTotalEntries.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalIntake.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblStreakCount.setFont(new Font("Segoe UI", Font.BOLD, 14));
        summaryPanel.add(lblTotalEntries);
        summaryPanel.add(lblTotalIntake);
        summaryPanel.add(lblStreakCount);

        JPanel centerPanel = new JPanel(new BorderLayout(8, 8));
        centerPanel.setOpaque(false);
        centerPanel.add(summaryPanel, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        // --- Button actions ---
        btnSave.addActionListener(e -> {
            saveProgress();
            loadProgress();
        });

        btnClear.addActionListener(e -> clearProgress());

        loadProgress();
        setVisible(true);
    }

    private void styleButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(new Color(100, 149, 237));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(5, 15, 5, 15));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { button.setBackground(new Color(70, 130, 180)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { button.setBackground(new Color(100, 149, 237)); }
        });
    }

    private void saveProgress() {
        String waterIntake = waterIntakeField.getText().trim();
        boolean dailyStreakCompleted = dailyStreakCheckbox.isSelected();
        if (waterIntake.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter water intake!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        try (FileWriter writer = new FileWriter("progress.txt", true)) {
            writer.write(currentDate + "," + waterIntake + "," + (dailyStreakCompleted ? "Yes" : "No") + "\n");
        } catch (IOException ex) { ex.printStackTrace(); }

        streakStatusLabel.setText("Progress saved for " + currentDate + "!");
        waterIntakeField.setText("");
        dailyStreakCheckbox.setSelected(false);
    }

    private void loadProgress() {
        tableModel.setRowCount(0);
        int totalEntries = 0, totalIntake = 0, streakCount = 0;
        try (Scanner scanner = new Scanner(new File("progress.txt"))) {
            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                if (data.length == 3) {
                    tableModel.addRow(data);
                    totalEntries++;
                    try { totalIntake += Integer.parseInt(data[1].trim()); } catch (NumberFormatException ignored) {}
                    if ("Yes".equalsIgnoreCase(data[2].trim())) streakCount++;
                }
            }
        } catch (FileNotFoundException ignored) {}
        lblTotalEntries.setText("Total Entries: " + totalEntries);
        lblTotalIntake.setText("Total Intake: " + totalIntake + " ml");
        lblStreakCount.setText("Streak Count: " + streakCount);
    }

    private void clearProgress() {
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to clear all data?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            try (FileWriter writer = new FileWriter("progress.txt")) {}
            catch (IOException ex) { ex.printStackTrace(); }
            loadProgress();
            streakStatusLabel.setText("All progress cleared!");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ProgressPage::new);
    }
}
