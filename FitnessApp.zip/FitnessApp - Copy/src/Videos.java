import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Videos extends JFrame {

    private JPanel contentPane;
    private String username;

    public Videos(String username) {
        this.username = username;
        setTitle("Workout Videos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 500);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(550, 450));

        // Main content panel with gradient background
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, new Color(245, 245, 245),
                        0, getHeight(), new Color(210, 235, 255));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                g2d.dispose();
            }
        };
        contentPane.setLayout(new BorderLayout(20, 20));
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);

        // Title
        JLabel lblTitle = new JLabel("Workout Videos", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitle.setForeground(new Color(30, 60, 120));
        lblTitle.setBorder(new EmptyBorder(10, 0, 10, 0));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);

        // Add subtle shadow to title
        lblTitle.setUI(new javax.swing.plaf.basic.BasicLabelUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setColor(new Color(150, 150, 150, 100));
                g2d.drawString(lblTitle.getText(), lblTitle.getInsets().left + 2, lblTitle.getInsets().top + 22);
                g2d.setColor(lblTitle.getForeground());
                g2d.drawString(lblTitle.getText(), lblTitle.getInsets().left, lblTitle.getInsets().top + 20);
                g2d.dispose();
            }
        });

        contentPane.add(lblTitle, BorderLayout.NORTH);

        // Panel to hold video buttons
        JPanel videosPanel = new JPanel();
        videosPanel.setLayout(new BoxLayout(videosPanel, BoxLayout.Y_AXIS));
        videosPanel.setOpaque(false); // gradient shows through

        // Add videos as styled buttons
        addVideoButton(videosPanel, "7-MINUTE FULL BODY Workout At Home", "https://youtu.be/5BwlDW0CAuU?si=WvtkdTdT7Bkqbmek");
        addVideoButton(videosPanel, "Do This Workout Every Evening - 10 Minute Full Body To Get In Shape", "https://youtu.be/agvdkRc_img?si=5QDPsuLaTglCmaw1");
        addVideoButton(videosPanel, "10 MIN MORNING EXERCISE FOR KIDS - ENERGY BOOST WORKOUT", "https://youtube.com/watch?v=Wj9SvxCpA4o&feature=shared");
        addVideoButton(videosPanel, "15 Min Stretching: Total Body Flexibility and Warm Up", "https://youtu.be/i7LJ-39bFgE?si=xjTa50Pp0tsvQ9tr");

        JScrollPane scrollPane = new JScrollPane(videosPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setOpaque(false);

        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Back button
        JButton btnBack = createBackButton();
        contentPane.add(btnBack, BorderLayout.SOUTH);
    }

    private void addVideoButton(JPanel panel, String text, String url) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(30, 144, 255), 0, getHeight(), new Color(100, 200, 255));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                super.paintComponent(g);
                g2.dispose();
            }
        };

        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);

        // Shadow effect
        btn.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setColor(new Color(0, 0, 0, 40));
                g2d.fillRoundRect(3, 3, c.getWidth(), c.getHeight(), 25, 25);
                super.paint(g2d, c);
                g2d.dispose();
            }
        });

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setForeground(Color.YELLOW);
            }
            public void mouseExited(MouseEvent e) {
                btn.setForeground(Color.WHITE);
            }
        });

        btn.addActionListener(e -> openWebpage(url));

        panel.add(btn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
    }

    private JButton createBackButton() {
        JButton btnBack = new JButton("BACK") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, new Color(255, 99, 71),
                        0, getHeight(), new Color(255, 140, 105));
                g2d.setPaint(gp);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                super.paintComponent(g2d);
                g2d.dispose();
            }
        };
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.setBorder(BorderFactory.createEmptyBorder());
        btnBack.setContentAreaFilled(false);
        btnBack.setOpaque(false);

        btnBack.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                btnBack.setForeground(Color.YELLOW);
            }

            public void mouseExited(MouseEvent evt) {
                btnBack.setForeground(Color.WHITE);
            }
        });

        btnBack.addActionListener(e -> {
            new Dashboard(username).setVisible(true);
            dispose();
        });
        return btnBack;
    }

    private void openWebpage(String url) {
        try {
            Desktop.getDesktop().browse(new URI(url));
        } catch (IOException | URISyntaxException e) {
            JOptionPane.showMessageDialog(this, "Unable to open link.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            String uname = JOptionPane.showInputDialog(null, "Enter your username:", "Username", JOptionPane.QUESTION_MESSAGE);
            if (uname == null || uname.trim().isEmpty()) uname = "Guest";
            Videos frame = new Videos(uname);
            frame.setVisible(true);
        });
    }
}
