public class UserDetails {
    private String username;
    private String name;
    private int age;
    private String gender;
    private String password;

    public UserDetails(String username, String name, int age, String gender, String password) {
        this.username = username;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.password = password;
    }

    // Getters
    public String getUsername() { return username; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public String getPassword() { return password; }

    // Setters
    public void setUsername(String username) { this.username = username; }
    public void setName(String name) { this.name = name; }
    public void setAge(int age) { this.age = age; }
    public void setGender(String gender) { this.gender = gender; }
    public void setPassword(String password) { this.password = password; }

    @Override
    public String toString() {
        return "UserDetails{" +
                "username='" + username + '\'' +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                ", password='" + password + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserDetails that = (UserDetails) o;

        if (age != that.age) return false;
        if (!username.equals(that.username)) return false;
        if (!name.equals(that.name)) return false;
        if (!gender.equals(that.gender)) return false;
        return password.equals(that.password);
    }

    @Override
    public int hashCode() {
        int result = username.hashCode();
        result = 31 * result + name.hashCode();
        result = 31 * result + age;
        result = 31 * result + gender.hashCode();
        result = 31 * result + password.hashCode();
        return result;
    }
}
