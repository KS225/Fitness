import javax.swing.*;
import java.awt.*;

public class DietPlanPage extends JFrame {

    private JComboBox<String> bmiCategoryComboBox;
    private JTextArea dietPlanArea;

    public DietPlanPage() {
        setTitle("Diet Plans");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 500);
        setMinimumSize(new Dimension(550, 450));
        setLocationRelativeTo(null); // Center on screen

        // Main panel with gradient background
        JPanel contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                Color color1 = new Color(245, 245, 245);
                Color color2 = new Color(220, 240, 255);
                g2d.setPaint(new GradientPaint(0, 0, color1, 0, getHeight(), color2));
                g2d.fillRect(0, 0, getWidth(), getHeight());
                g2d.dispose();
            }
        };
        contentPane.setLayout(new GridBagLayout());
        setContentPane(contentPane);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // Title label
        JLabel lblTitle = new JLabel("Select Your BMI Category for Diet Plans", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(new Color(30, 60, 120));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weighty = 0.0;
        contentPane.add(lblTitle, gbc);

        // BMI dropdown
        bmiCategoryComboBox = new JComboBox<>(new String[]{"Select...", "Underweight", "Normal Weight", "Overweight", "Obese"});
        bmiCategoryComboBox.setBackground(new Color(220, 220, 220)); // Neutral color
        bmiCategoryComboBox.setForeground(new Color(50, 50, 50));
        bmiCategoryComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        gbc.gridy = 1;
        contentPane.add(bmiCategoryComboBox, gbc);

        // Diet plan output
        dietPlanArea = new JTextArea();
        dietPlanArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        dietPlanArea.setLineWrap(true);
        dietPlanArea.setWrapStyleWord(true);
        dietPlanArea.setEditable(false);
        dietPlanArea.setBackground(new Color(250, 250, 250));
        dietPlanArea.setForeground(new Color(40, 40, 40));
        dietPlanArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane scrollPane = new JScrollPane(dietPlanArea);
        scrollPane.setPreferredSize(new Dimension(500, 250));
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        contentPane.add(scrollPane, gbc);

        // Show Diet Plan button
        JButton btnShowDietPlan = new JButton("Show Diet Plan");
        btnShowDietPlan.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnShowDietPlan.setForeground(Color.WHITE);
        btnShowDietPlan.setBackground(new Color(70, 130, 180)); // Steel blue
        btnShowDietPlan.setFocusPainted(false);
        btnShowDietPlan.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect
        btnShowDietPlan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnShowDietPlan.setBackground(new Color(100, 160, 210));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnShowDietPlan.setBackground(new Color(70, 130, 180));
            }
        });

        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weighty = 0.0;
        contentPane.add(btnShowDietPlan, gbc);

        // Button action
        btnShowDietPlan.addActionListener(e -> {
            String selectedCategory = (String) bmiCategoryComboBox.getSelectedItem();
            displayDietPlan(selectedCategory);
        });
    }

    private void displayDietPlan(String category) {
        String dietPlan = "";
        switch (category) {
            case "Select...": dietPlan = "Please select a BMI category."; break;
            case "Underweight": dietPlan = getUnderweightDietPlan(); break;
            case "Normal Weight": dietPlan = getNormalWeightDietPlan(); break;
            case "Overweight": dietPlan = getOverweightDietPlan(); break;
            case "Obese": dietPlan = getObeseDietPlan(); break;
        }
        dietPlanArea.setText(dietPlan);
    }

    private String getUnderweightDietPlan() {
        return "=== DIET PLAN FOR UNDERWEIGHT ===\n\n" +
                "• Increase calorie intake with nutrient-dense foods.\n" +
                "• Eat frequent meals and healthy snacks.\n" +
                "• Include protein-rich foods like eggs, chicken, beans.\n" +
                "• Add healthy fats like avocado, nuts, seeds.\n" +
                "• Stay hydrated.\n"+
                "• Please contact a Dietician for more detailed plan.\n";
    }

    private String getNormalWeightDietPlan() {
        return "=== DIET PLAN FOR NORMAL WEIGHT ===\n\n" +
                "• Maintain a balanced diet with all food groups.\n" +
                "• Include lean proteins, whole grains, and vegetables.\n" +
                "• Monitor portion sizes.\n" +
                "• Drink plenty of water.\n";
    }

    private String getOverweightDietPlan() {
        return "=== DIET PLAN FOR OVERWEIGHT ===\n\n" +
                "• Focus on whole, unprocessed foods.\n" +
                "• Limit high-calorie, sugary, and fatty foods.\n" +
                "• Increase fiber intake.\n" +
                "• Include lean proteins like fish and poultry.\n"+
                "• Please contact a Dietician for more detailed plan.\n";
        
    }

    private String getObeseDietPlan() {
        return "=== DIET PLAN FOR OBESE ===\n\n" +
                "• Follow a calorie-controlled meal plan.\n" +
                "• Focus on high-fiber foods: fruits, vegetables, whole grains.\n" +
                "• Minimize processed foods and sugary drinks.\n" +
                "• Include healthy fats like nuts and olive oil.\n"+
                "• Please contact a Dietician for more detailed plan.\n";
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DietPlanPage().setVisible(true));
    }
}
