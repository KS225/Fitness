import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.net.URL;
import java.text.NumberFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Profile extends JFrame {
    
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField emailField;
    private JTextField nameField;
    private JFormattedTextField ageField;
    private JComboBox<String> genderComboBox;
    private JPasswordField passwordField;
    private JButton showPasswordButton;
    private boolean isPasswordVisible = false; // Flag to track password visibility
    
    // Define standard dimensions and styles
    private final int FRAME_WIDTH = 400;
    private final int FRAME_HEIGHT = 500;
    private final Color BUTTON_COLOR = new Color(70, 130, 180);
    private final Color BUTTON_TEXT_COLOR = Color.WHITE;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Profile frame = new Profile();
                frame.setVisible(true);
                frame.setAlwaysOnTop(true); // Ensure the frame is always on top
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Profile() {
      	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	    setBounds(100, 100, FRAME_WIDTH, FRAME_HEIGHT); // Set standardized dimensions
    	    setResizable(false); // Prevent resizing, removes minimize and maximize buttons
    	    contentPane = new JPanel();
    	    contentPane.setBackground(new Color(240, 248, 255)); // Light background color
    	    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    	    setContentPane(contentPane);
    	    contentPane.setLayout(null);

        JPanel signinPanel = new JPanel();
        signinPanel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, Color.BLACK, null));
        signinPanel.setBounds(30, 30, 340, 400);
        signinPanel.setBackground(Color.WHITE); // Panel background color
        contentPane.add(signinPanel);
        signinPanel.setLayout(null);

        JLabel signInLabel = new JLabel("Sign In");
        signInLabel.setForeground(Color.BLACK);
        signInLabel.setFont(new Font("Cambria", Font.BOLD, 24));
        signInLabel.setHorizontalAlignment(SwingConstants.CENTER);
        signInLabel.setBounds(32, 10, 255, 34);
        signinPanel.add(signInLabel);

        JLabel nameLabel = new JLabel("NAME : ");
        nameLabel.setFont(new Font("Cambria", Font.BOLD, 14));
        nameLabel.setBounds(10, 41, 144, 34);
        signinPanel.add(nameLabel);

        nameField = new JTextField();
        nameField.setColumns(10);
        nameField.setBounds(10, 71, 298, 19);
        signinPanel.add(nameField);

        JLabel ageLabel = new JLabel("AGE :");
        ageLabel.setFont(new Font("Cambria", Font.BOLD, 14));
        ageLabel.setBounds(10, 100, 45, 13);
        signinPanel.add(ageLabel);

        ageField = new JFormattedTextField(NumberFormat.getIntegerInstance());
        ageField.setColumns(10);
        ageField.setBounds(10, 116, 78, 19);
        signinPanel.add(ageField);

        JLabel genderLabel = new JLabel("GENDER :");
        genderLabel.setFont(new Font("Cambria", Font.BOLD, 14));
        genderLabel.setBounds(150, 99, 94, 13);
        signinPanel.add(genderLabel);

        genderComboBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderComboBox.setBounds(153, 116, 155, 19);
        signinPanel.add(genderComboBox);

        JLabel emailLabel = new JLabel("EMAIL ID :");
        emailLabel.setFont(new Font("Cambria", Font.BOLD, 16));
        emailLabel.setBounds(10, 145, 88, 22);
        signinPanel.add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(10, 172, 298, 19);
        signinPanel.add(emailField);
        emailField.setColumns(10);

       // Label for password
        JLabel passwordLabel = new JLabel("PASSWORD :");
        passwordLabel.setFont(new Font("Cambria", Font.BOLD, 14));
        passwordLabel.setBounds(10, 201, 99, 22);
        signinPanel.add(passwordLabel);

        // Password field
        passwordField = new JPasswordField();
        passwordField.setColumns(10);
        passwordField.setBounds(10, 229, 298, 19); // Password field
        signinPanel.add(passwordField);

        // Checkbox for show password
        JCheckBox showPasswordCheckBox = new JCheckBox("Show Password");
        showPasswordCheckBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        showPasswordCheckBox.setBounds(10, 260, 150, 20); // Positioned directly under the password field
        showPasswordCheckBox.addActionListener(e -> {
            if (showPasswordCheckBox.isSelected()) {
                passwordField.setEchoChar((char) 0); // Show password
            } else {
                passwordField.setEchoChar('*'); // Hide password
            }
        });
        signinPanel.add(showPasswordCheckBox); // Add checkbox to panel

        JButton createButton = createStandardButton("CREATE");
        createButton.addActionListener(e -> handleCreateButton());
        createButton.setBounds(32, 287, 94, 21);
        signinPanel.add(createButton);

        JButton backButton = createStandardButton("BACK");
        backButton.addActionListener(e -> {
            LoginProfile loginFrame = new LoginProfile();
            loginFrame.setVisible(true);
            dispose();
        });
        backButton.setBounds(193, 287, 94, 21);
        signinPanel.add(backButton);

        
    }

    private JButton createStandardButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Cambria", Font.BOLD, 14));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(BUTTON_TEXT_COLOR);
        button.setFocusPainted(false); // Remove focus border
        button.setBorder(new LineBorder(Color.GRAY, 1, true)); // Rounded border
        return button;
    }

    private void handleCreateButton() {
        System.out.println("Create button clicked");

        if (!areFieldsValid()) {
            System.out.println("Validation failed");
            return;
        }

        String name = nameField.getText();
        int age = Integer.parseInt(ageField.getText());
        String gender = (String) genderComboBox.getSelectedItem();
        String username = emailField.getText();
        String password = new String(passwordField.getPassword());

        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Gender: " + gender);
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);

        if (isUsernameTaken(username)) {
            showErrorDialog("This email is already registered. Please use a different email or log in.");
            return;
        }

        if (isPasswordTaken(password)) {
            showErrorDialog("This password is already in use. Please choose a different password.");
            return;
        }

        String hashedPassword = Conn.hashPassword(password);
        if (hashedPassword == null) {
            showErrorDialog("An error occurred while processing your password. Please try again.");
            return;
        }

        UserDetails userDetails = new UserDetails(username, name, age, gender, hashedPassword);
        Conn.insertRecord(userDetails);

        JOptionPane.showMessageDialog(this, "User created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

        // Open BMI Calculator after successful account creation
        Calci calciFrame = new Calci();
        calciFrame.setVisible(true);
        dispose();
    }

    private boolean areFieldsValid() {
        if (nameField.getText().isEmpty() || ageField.getText().isEmpty() ||
                emailField.getText().isEmpty() || passwordField.getPassword().length == 0) {
            showErrorDialog("All fields are required.");
            return false;
        }

        if (!isValidEmail(emailField.getText())) {
            showErrorDialog("Please enter a valid Gmail address.");
            return false;
        }

        if (Integer.parseInt(ageField.getText()) < 18) {
            showErrorDialog("You must be at least 18 years old.");
            return false;
        }

        return true;
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9._%+-]+@gmail\\.com$"; // Allow only Gmail addresses
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private boolean isUsernameTaken(String username) {
        // Placeholder for username existence check
        return false;
    }

    private boolean isPasswordTaken(String password) {
        // Placeholder for password existence check
        return false;
    }

    private void togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible;
        passwordField.setEchoChar(isPasswordVisible ? '\u0000' : '*'); // Show or hide password
    }

    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
}