import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class Dashboard extends JFrame {

    private JPanel contentPane;
    private String username;

    public Dashboard(String uname) {
        this.username = uname;
        setTitle("Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 800);
        setMinimumSize(new Dimension(700, 700));
        setLocationRelativeTo(null);

        // Main panel with gradient background
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                Color color1 = new Color(245, 245, 245);
                Color color2 = new Color(220, 235, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        contentPane.setLayout(new GridBagLayout());
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));

        JScrollPane scrollPane = new JScrollPane(contentPane);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        setContentPane(scrollPane);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;

        // Title
        JLabel lblTitle = new JLabel("Welcome, " + username, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(new Color(30, 60, 90));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        contentPane.add(lblTitle, gbc);
        gbc.gridwidth = 1;

        // Dashboard Buttons (Big panels)
        addDashboardButton("Profile", new Color(255, 204, 204), e -> openProfilePage(), gbc, 1, 0);
        addDashboardButton("Videos", new Color(204, 255, 204), e -> openVideosWindow(), gbc, 1, 1);
        addDashboardButton("BMI Calculator", new Color(204, 204, 255), e -> openBMIWindow(), gbc, 2, 0);
        addDashboardButton("Progress", new Color(255, 255, 204), e -> showProgressSection(), gbc, 2, 1);
        addDashboardButton("Diet", new Color(204, 255, 204), e -> openDietWindow(), gbc, 3, 0);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0;
        contentPane.add(Box.createVerticalGlue(), gbc);

        setVisible(true);
    }

    // Modern gradient button
    private JButton createGradientButton(String text, ActionListener action) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color start = new Color(30, 144, 255);
                Color end = new Color(100, 200, 255);
                GradientPaint gp = new GradientPaint(0, 0, start, 0, getHeight(), end);
                g2d.setPaint(gp);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2d.dispose();
                super.paintComponent(g);
            }
        };
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setBorderPainted(false); // Remove visible border
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(action);

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setForeground(new Color(230, 230, 255));
            }

            public void mouseExited(MouseEvent evt) {
                button.setForeground(Color.WHITE);
            }
        });

        return button;
    }

    private void addDashboardButton(String title, Color bgColor, ActionListener action, GridBagConstraints gbc, int row, int col) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(bgColor);
        panel.setBorder(new CompoundBorder(
                new LineBorder(new Color(150, 150, 150), 2, true),
                new EmptyBorder(15, 15, 15, 15)
        ));
        panel.setPreferredSize(new Dimension(300, 180));

        // Title label
        JLabel lbl = new JLabel(title, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbl.setForeground(new Color(50, 50, 50));
        panel.add(lbl, BorderLayout.NORTH);

        // Centered gradient "Open" button
        JButton btn = createGradientButton("Open", action);
        btn.setPreferredSize(new Dimension(250, 40));

        JPanel btnWrapper = new JPanel(new GridBagLayout());
        btnWrapper.setOpaque(false);
        btnWrapper.add(btn);
        panel.add(btnWrapper, BorderLayout.CENTER);

        gbc.gridx = col;
        gbc.gridy = row;
        gbc.weighty = 0.0;
        contentPane.add(panel, gbc);
    }

    // Page openers
    private void openProfilePage() { new ProfilePage(username).setVisible(true); }
    private void openBMIWindow() { new BMI(username, this).setVisible(true); }
    private void openVideosWindow() { new Videos(username).setVisible(true); }
    private void openDietWindow() { new DietPlanPage().setVisible(true); }
    private void showProgressSection() { new ProgressPage().setVisible(true); }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Dashboard("User"));
    }
}
